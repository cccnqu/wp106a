# Markdown 編輯器 -- mdeditor 

使用 Electron.js 撰寫的一個 Markdown 編輯器。

採用 marked 這個 npm 套件將 markdown 轉為 HTML 呈現。

目前支援 github flavored markdown (GFM)，也就是支援表格，預設超連結等功能。