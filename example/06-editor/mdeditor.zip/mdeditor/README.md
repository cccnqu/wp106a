# 參考：

https://electron.atom.io/docs/api/menu/